# kennzeichen-lightburn-export

Production-grade **Fabric.js → LightBurn** export system for Austrian license plate frame designs (DSTU 4278 / 525×145 mm frame, 520×112 mm print area).

## Architecture

```
Fabric.js editor/preview (unchanged UI)
        ↓
Real Fabric object geometry + transforms (calcTransformMatrix, bbox, scale, rotation)
        ↓
Viewport-independent design-space StaticCanvas (3651×2132 px)
        ↓
Normalized fixed mm coordinates (lightburn-mm-bottom-left)
        ↓
Stable production geometry layer (validated scene)
        ↓
SVG + LBRN2 generation
        ↓
LightBurn output identical to preview
```

### Client (`public/js/`)

| Module | Role |
|--------|------|
| `fabric-production-pipeline.js` | Production canvas resolver, Fabric geometry normalizer, geometry/parity validators |
| `preview-engine.js` | Fabric preview + WYSIWYG export via fixed design-space StaticCanvas |
| `canonical-scene.js` | Canonical scene JSON from Fabric-sourced layout |

### Server (`includes/`)

| Class | Role |
|-------|------|
| `PCKZ_Production_Pipeline` | Orchestrates validation → production scene → SVG/LBRN2 |
| `PCKZ_Fabric_Geometry_Normalizer` | Uses canonical Fabric geometry (no manual layout rebuild) |
| `PCKZ_Geometry_Validator` | Plate/object bbox validation |
| `PCKZ_Export_Parity` | Canonical vs production layer parity |
| `PCKZ_Production_Scene` | Master SVG → layer model |
| `PCKZ_Production_Svg` / `PCKZ_Production_Lbrn2` | Output generators |

### Physical dimensions (immutable preset)

- Frame: **525 × 145 mm** (52.5 × 14.5 cm)
- Safe print area: **520 × 112 mm**
- Design reference: **3651 × 2132 px** (Cloudlift)

## Export parity (v2.9.3)

- Fabric preview objects are cloned **pixel-for-pixel** into the export StaticCanvas (no design-space rescaling).
- Production SVG uses a **single** `pckz-engrave` transform; server parsing preserves Fabric subpaths (no spurious lines between contours).
- OpenType text rebuild is disabled; text comes from Fabric `toSVG` like icons/lines.

## Development

Smoke tests (Node, from `tests/node/`):

```bash
cd tests/node && npm install && npm test
```

PHP smoke tests require WordPress bootstrap (`tests/*-smoke.php`).

