#!/usr/bin/env node
/**
 * Integration verification for Naruto eye models without WordPress runtime.
 * Mirrors preview-engine tint logic and validates SVG assets for export compatibility.
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const LINES = path.join(ROOT, 'public/assets/lines');
const START = 102;
const COUNT = 10;

const EXPECTED = {
  type_102: 'Sharingan (3 Tomoe)',
  type_103: 'Mangekyo Sharingan',
  type_104: 'Rinnegan',
  type_105: 'Mangekyo (Itachi)',
  type_106: 'Rinnegan (Tomoe)',
  type_107: 'Byakugan',
  type_108: 'Sage Mode',
  type_109: 'Tenseigan',
  type_110: 'Ketsuryugan',
  type_111: 'Eien no Mangekyo Sharingan',
};

function fail(msg) {
  console.error('FAIL', msg);
  process.exit(1);
}

function chromaticFills(svg) {
  const re = /fill="([^"]+)"/gi;
  const colors = new Set();
  let m;
  while ((m = re.exec(svg))) {
    const c = m[1].toLowerCase();
    if (c === 'none' || c === 'transparent') continue;
    colors.add(c);
  }
  let chromatic = 0;
  for (const c of colors) {
    if (/^#[0-9a-f]{6}$/i.test(c)) {
      const r = parseInt(c.slice(1, 3), 16);
      const g = parseInt(c.slice(3, 5), 16);
      const b = parseInt(c.slice(5, 7), 16);
      if (Math.max(r, g, b) - Math.min(r, g, b) > 8) chromatic++;
    }
  }
  return { chromatic, total: colors.size };
}

function resolveLineTint(meta, lineColor) {
  if (meta.preserve_colors || meta.tintable === false) return null;
  return lineColor || '#ffffff';
}

function parseLabelsPhp() {
  const text = fs.readFileSync(path.join(ROOT, 'includes/bundled-line-labels.php'), 'utf8');
  const labels = {};
  const re = /'(type_\d+)'\s*=>\s*'([^']+)'/g;
  let m;
  while ((m = re.exec(text))) labels[m[1]] = m[2];
  return labels;
}

function main() {
  const labels = parseLabelsPhp();
  let ok = 0;

  for (let i = START; i < START + COUNT; i++) {
    const slug = `type_${i}`;
    const file = path.join(LINES, `${slug}.svg`);
    if (!fs.existsSync(file)) fail(`missing ${file}`);
    const svg = fs.readFileSync(file, 'utf8');

    if (!/viewBox="0 0 950 35"/.test(svg)) fail(`${slug}: bad viewBox`);
    if (labels[slug] !== EXPECTED[slug]) {
      fail(`${slug}: label ${labels[slug]} != ${EXPECTED[slug]}`);
    }

    const { chromatic, total } = chromaticFills(svg);
    if (chromatic < 10) fail(`${slug}: insufficient chromatic fills (${chromatic})`);
    if (total < 20) fail(`${slug}: too few fill colors (${total}) — possible mono conversion`);

    const meta = { preserve_colors: true, tintable: false };
    const tint = resolveLineTint(meta, '#b22222');
    if (tint !== null) fail(`${slug}: preview would incorrectly tint preserve_colors line`);

    // Export asset URL pattern (bundled lines use direct public path)
    const exportUrl = `public/assets/lines/${slug}.svg`;
    if (!fs.existsSync(path.join(ROOT, exportUrl))) fail(`${slug}: export asset missing`);

    // Picker preview query pattern
    const pickerUrl = `?pckz_line_picker=${slug}`;
    if (!pickerUrl.includes(slug)) fail(`${slug}: picker URL pattern broken`);

    // LBRN2: colored paths must remain as fill attributes (not stripped to mono)
    if (!/fill="#[0-9A-Fa-f]{6}"/.test(svg)) fail(`${slug}: no hex fill paths for LightBurn export`);

    ok++;
  }

  // Verify all 10 in git HEAD
  const { execSync } = require('child_process');
  for (let i = START; i < START + COUNT; i++) {
    try {
      execSync(`git cat-file -e HEAD:public/assets/lines/type_${i}.svg`, { cwd: ROOT, stdio: 'pipe' });
    } catch {
      fail(`type_${i}.svg not in git HEAD`);
    }
  }

  console.log(`OK naruto-integration: ${ok} models — preserve_colors, labels, export paths, no tint`);
}

main();
