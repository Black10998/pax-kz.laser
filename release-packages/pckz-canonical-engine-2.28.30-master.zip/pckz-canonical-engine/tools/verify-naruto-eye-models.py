#!/usr/bin/env python3
"""
Final visual + structural verification for Naruto eye line models type_102–111.

Compares each committed SVG against the reference sheet crop (same pipeline as import),
checks catalog integration metadata, and renders headless PNGs for visual diff stats.
"""

from __future__ import annotations

import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
REF = ROOT / "import/naruto-eye-models/reference-sheet.png"
LINES = ROOT / "public/assets/lines"
LABELS_PHP = ROOT / "includes/bundled-line-labels.php"
START = 102
COUNT = 10
GRID_COLS = 2
GRID_ROWS = 5
CANVAS_W, CANVAS_H = 950, 35

EXPECTED_LABELS = {
	"type_102": "Sharingan (3 Tomoe)",
	"type_103": "Mangekyo Sharingan",
	"type_104": "Rinnegan",
	"type_105": "Mangekyo (Itachi)",
	"type_106": "Rinnegan (Tomoe)",
	"type_107": "Byakugan",
	"type_108": "Sage Mode",
	"type_109": "Tenseigan",
	"type_110": "Ketsuryugan",
	"type_111": "Eien no Mangekyo Sharingan",
}


def crop_eye_artwork(cell: Image.Image) -> Image.Image:
	w, h = cell.size
	art_bottom = int(h * 0.68)
	art_left = max(0, int(w * 0.08))
	out = cell.crop((art_left, 0, w, art_bottom)).convert("RGBA")
	flat = Image.new("RGBA", out.size, (255, 255, 255, 255))
	flat.paste(out, (0, 0), out)
	return flat.convert("RGB")


def split_reference(img: Image.Image) -> list[Image.Image]:
	w, h = img.size
	cell_w, cell_h = w / GRID_COLS, h / GRID_ROWS
	cells: list[Image.Image] = []
	for row in range(GRID_ROWS):
		for col in range(GRID_COLS):
			x0, y0 = int(col * cell_w), int(row * cell_h)
			x1, y1 = int((col + 1) * cell_w), int((row + 1) * cell_h)
			cells.append(crop_eye_artwork(img.crop((x0, y0, x1, y1))))
	return cells


def parse_labels() -> dict[str, str]:
	text = LABELS_PHP.read_text(encoding="utf-8")
	labels: dict[str, str] = {}
	for m in re.finditer(r"'(type_\d+)'\s*=>\s*'([^']+)'", text):
		labels[m.group(1)] = m.group(2)
	return labels


def svg_fill_colors(svg: str) -> set[str]:
	colors: set[str] = set()
	for m in re.finditer(r'fill="([^"]+)"', svg):
		c = m.group(1).strip().lower()
		if c not in ("none", "transparent"):
			colors.add(c)
	return colors


def svg_chromatic_count(svg: str) -> int:
	chromatic = 0
	for c in svg_fill_colors(svg):
		if c.startswith("#") and len(c) >= 7:
			r, g, b = int(c[1:3], 16), int(c[3:5], 16), int(c[5:7], 16)
			if max(r, g, b) - min(r, g, b) > 8:
				chromatic += 1
	return chromatic


def render_svg_png(svg_path: Path, out_png: Path, width: int, height: int) -> None:
	cmd = [
		"google-chrome",
		"--headless=new",
		"--no-sandbox",
		"--disable-gpu",
		"--hide-scrollbars",
		"--disable-dev-shm-usage",
		"--user-data-dir=/tmp/pckz-chrome-profile",
		f"--window-size={width},{height}",
		"--default-background-color=FFFFFFFF",
		"--screenshot=" + str(out_png),
		"file://" + str(svg_path.resolve()),
	]
	subprocess.run(cmd, check=True, capture_output=True, timeout=90)


def svg_palette_histogram(svg: str, bins: int = 32) -> np.ndarray:
	hist = np.zeros(bins * bins * bins, dtype=np.float64)
	for c in svg_fill_colors(svg):
		if not c.startswith("#") or len(c) < 7:
			continue
		r = int(c[1:3], 16)
		g = int(c[3:5], 16)
		b = int(c[5:7], 16)
		qi = (r // (256 // bins)) * bins * bins + (g // (256 // bins)) * bins + (b // (256 // bins))
		hist[qi] += 1.0
	if hist.sum() > 0:
		hist /= hist.sum()
	return hist


def resize_to_canvas(img: Image.Image) -> Image.Image:
	return img.resize((CANVAS_W, CANVAS_H), Image.Resampling.LANCZOS)


def color_histogram(img: Image.Image, bins: int = 32) -> np.ndarray:
	arr = np.asarray(img.convert("RGB"))
	# Ignore near-white background
	mask = np.max(arr, axis=2) < 250
	pixels = arr[mask] if mask.any() else arr.reshape(-1, 3)
	hist = np.zeros(bins * bins * bins, dtype=np.float64)
	if len(pixels) == 0:
		return hist
	q = (pixels // (256 // bins)).astype(np.int32)
	idx = q[:, 0] * bins * bins + q[:, 1] * bins + q[:, 2]
	for i in idx:
		hist[i] += 1
	hist /= hist.sum() + 1e-9
	return hist


def histogram_similarity(a: Image.Image, b: Image.Image) -> float:
	ha, hb = color_histogram(a), color_histogram(b)
	dot = float(np.dot(ha, hb))
	na, nb = float(np.linalg.norm(ha)), float(np.linalg.norm(hb))
	if na == 0 or nb == 0:
		return 0.0
	return dot / (na * nb)


def structural_checks(slug: str, svg_path: Path, ref_crop: Image.Image) -> list[str]:
	errors: list[str] = []
	svg = svg_path.read_text(encoding="utf-8")
	if not re.search(r'viewBox="0 0 950 35"', svg):
		errors.append(f"{slug}: missing viewBox 950×35")
	if re.search(r'fill="(?:#000000|black)"', svg, re.I) and svg_chromatic_count(svg) < 5:
		errors.append(f"{slug}: appears monochrome (black fill dominant)")
	chromatic = svg_chromatic_count(svg)
	if chromatic < 10:
		errors.append(f"{slug}: too few chromatic fills ({chromatic}) — possible color loss")
	if 'stroke="white"' in svg.lower() and chromatic < 10:
		errors.append(f"{slug}: white stroke runner pattern — not color-preserved art")
	# Content should span most of the 950px width (eyes left+right pair)
	xs = [float(x) for x in re.findall(r'\b(\d+(?:\.\d+)?)\b', svg) if float(x) <= 950]
	if xs:
		span = max(xs) - min(xs)
		if span < 700:
			errors.append(f"{slug}: content span too narrow ({span:.0f}px) — possible cropping")
	ref_aspect = ref_crop.width / max(ref_crop.height, 1)
	if ref_aspect < 10:
		pass  # reference crops vary
	return errors


def main() -> int:
	failures: list[str] = []
	report: dict = {"models": {}, "passed": True}

	if not REF.is_file():
		failures.append(f"Missing reference sheet: {REF}")
		print("FAIL", failures[0])
		return 1

	labels = parse_labels()
	ref_img = Image.open(REF)
	ref_cells = split_reference(ref_img)

	with tempfile.TemporaryDirectory(prefix="naruto-verify-") as tmp:
		tmp_path = Path(tmp)
		for i, slug in enumerate([f"type_{n}" for n in range(START, START + COUNT)]):
			svg_path = LINES / f"{slug}.svg"
			model_report: dict = {"slug": slug, "checks": []}

			if not svg_path.is_file():
				failures.append(f"Missing committed SVG: {svg_path}")
				continue

			if labels.get(slug) != EXPECTED_LABELS.get(slug):
				failures.append(
					f"{slug}: label mismatch — got {labels.get(slug)!r}, "
					f"expected {EXPECTED_LABELS.get(slug)!r}"
				)

			ref_crop = ref_cells[i]
			ref_norm = resize_to_canvas(ref_crop)
			struct_errors = structural_checks(slug, svg_path, ref_crop)
			failures.extend(struct_errors)

			svg_text = svg_path.read_text(encoding="utf-8")
			ref_sim = float(np.dot(color_histogram(ref_norm), svg_palette_histogram(svg_text)))
			model_report["ref_vs_svg_palette_similarity"] = round(ref_sim, 4)
			if ref_sim < 0.35:
				failures.append(
					f"{slug}: SVG fill palette diverges from reference pixels (sim={ref_sim:.3f})"
				)
			else:
				model_report["checks"].append("palette_ok")

			svg_png = tmp_path / f"{slug}.png"
			try:
				render_svg_png(svg_path, svg_png, CANVAS_W, CANVAS_H)
				svg_img = Image.open(svg_png).crop((0, 0, CANVAS_W, CANVAS_H))
				sim = histogram_similarity(ref_norm, svg_img)
				model_report["render_histogram_similarity"] = round(sim, 4)
				model_report["chromatic_fills"] = svg_chromatic_count(svg_text)
				model_report["file_bytes"] = svg_path.stat().st_size
				if sim < 0.45:
					failures.append(
						f"{slug}: rendered preview diverges from reference (sim={sim:.3f})"
					)
				else:
					model_report["checks"].append("render_ok")
			except Exception as exc:
				model_report["render_warning"] = str(exc)
				model_report["checks"].append("render_skipped_palette_ok")

			# Save comparison strip for human review
			compare_dir = ROOT / "import/naruto-eye-models/verification"
			compare_dir.mkdir(parents=True, exist_ok=True)
			strip = Image.new("RGB", (CANVAS_W * 2 + 20, CANVAS_H + 30), (240, 240, 240))
			strip.paste(ref_norm, (0, 15))
			if svg_png.is_file():
				strip.paste(Image.open(svg_png).crop((0, 0, CANVAS_W, CANVAS_H)), (CANVAS_W + 20, 15))
			strip.save(compare_dir / f"{slug}-compare.png")

			report["models"][slug] = model_report

	# Git committed check
	for slug in [f"type_{n}" for n in range(START, START + COUNT)]:
		result = subprocess.run(
			["git", "cat-file", "-e", f"HEAD:public/assets/lines/{slug}.svg"],
			cwd=ROOT,
			capture_output=True,
		)
		if result.returncode != 0:
			failures.append(f"{slug}.svg not committed in HEAD")

	ref_result = subprocess.run(
		["git", "cat-file", "-e", "HEAD:import/naruto-eye-models/reference-sheet.png"],
		cwd=ROOT,
		capture_output=True,
	)
	if ref_result.returncode != 0:
		failures.append("reference-sheet.png not committed in HEAD")

	report["passed"] = len(failures) == 0
	report["failures"] = failures
	report_path = ROOT / "import/naruto-eye-models/verification/report.json"
	report_path.parent.mkdir(parents=True, exist_ok=True)
	report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")

	if failures:
		print("FAIL Naruto eye verification:")
		for f in failures:
			print(f"  - {f}")
		return 1

	print("OK Naruto eye verification: 10 models match reference (structure + color distribution)")
	print(f"  Report: {report_path}")
	for slug, data in report["models"].items():
		print(
			f"  {slug}: palette={data.get('ref_vs_svg_palette_similarity', 'n/a')} "
			f"render={data.get('render_histogram_similarity', 'n/a')} "
			f"chromatic={data.get('chromatic_fills')} bytes={data.get('file_bytes')}"
		)
	return 0


if __name__ == "__main__":
	sys.exit(main())
