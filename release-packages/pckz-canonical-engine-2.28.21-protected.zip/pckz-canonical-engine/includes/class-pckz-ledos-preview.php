<?php
/**
 * Cloudlift-compatible preview layout (3651×2132 design space).
 *
 * @package PCKZCanonicalEngine
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class PCKZ_Ledos_Preview
 */
class PCKZ_Ledos_Preview {

	/**
	 * Original Cloudlift canvas size (px).
	 */
	const DESIGN_WIDTH  = 3651;
	const DESIGN_HEIGHT = 2132;

	/** Original Cloudlift icon refX before centerward calibration (~0.5 cm / 5 mm inward). */
	const ICON_LEFT_REF_X_ORIGINAL  = 816;
	const ICON_RIGHT_REF_X_ORIGINAL = 2750;
	const ICON_CENTER_INWARD_MM     = 5.0;

	/**
	 * Icon layer refX after ~0.5 cm inward shift from original Cloudlift layout.
	 *
	 * @param string $side left|right
	 * @return float
	 */
	public static function icon_ref_x( $side ) {
		$shift = ( self::ICON_CENTER_INWARD_MM / 529.1 ) * self::DESIGN_WIDTH;
		if ( 'right' === $side ) {
			return self::ICON_RIGHT_REF_X_ORIGINAL - $shift;
		}
		return self::ICON_LEFT_REF_X_ORIGINAL + $shift;
	}

	/**
	 * Config payload for JavaScript preview engine.
	 *
	 * @return array
	 */
	public static function config_for_js() {
		return array(
			'designWidth'  => self::DESIGN_WIDTH,
			'designHeight' => self::DESIGN_HEIGHT,
			'layers'       => self::layer_refs(),
			'lineTypes'    => self::line_types_for_preview_js(),
			'lineCatalog'  => self::line_catalog_for_js(),
			'iconCatalog'  => self::icon_catalog(),
			'colors'       => self::color_swatches(),
		);
	}

	/**
	 * Reference rectangles from Cloudlift previewConfig (Ledos frame).
	 *
	 * @return array
	 */
	public static function layer_refs() {
		return array(
			'text'         => array(
				'refX'      => 1136,
				'refY'      => 1256,
				'refWidth'  => 1392,
				'refHeight' => 93,
				'fontSize'  => 55,
				'stroke'    => 30,
			),
			'iconLeft'     => array(
				'refX'      => self::icon_ref_x( 'left' ),
				'refY'      => 1243,
				'refWidth'  => 81,
				'refHeight' => 114,
			),
			'iconRight'    => array(
				'refX'      => self::icon_ref_x( 'right' ),
				'refY'      => 1243,
				'refWidth'  => 81,
				'refHeight' => 114,
			),
			'iconBgLeft'   => array(
				'refX'      => 767,
				'refY'      => 1244,
				'refWidth'  => 178,
				'refHeight' => 113,
				'url'       => 'https://cdn.shopify.com/s/files/1/0746/3672/2449/files/a_Tx6b_Icon_background.svg',
			),
			'iconBgRight'  => array(
				'refX'      => 2700,
				'refY'      => 1244,
				'refWidth'  => 178,
				'refHeight' => 113,
				'url'       => 'https://cdn.shopify.com/s/files/1/0746/3672/2449/files/a_Tx6b_Icon_background.svg',
			),
			'lines'        => array(
				'refX'      => 609,
				'refY'      => 1173,
				'refWidth'  => 2424,
				'refHeight' => 254,
			),
		);
	}

	/**
	 * Bundled line ornament directory (type_21+), relative to plugin root.
	 */
	const LINE_ASSETS_DIR = 'public/assets/lines/';

	/**
	 * First / last bundled line type index (model 21–91 SVGs).
	 */
	const BUNDLED_LINE_TYPE_MIN = 21;
	const BUNDLED_LINE_TYPE_MAX = 101;

	/**
	 * Absolute path to bundled line SVG directory.
	 *
	 * @return string
	 */
	public static function line_assets_dir() {
		return trailingslashit( PCKZCE_PLUGIN_DIR ) . self::LINE_ASSETS_DIR;
	}

	/**
	 * Public URL for bundled line SVG directory.
	 *
	 * @return string
	 */
	public static function line_assets_url() {
		return trailingslashit( PCKZCE_PLUGIN_URL ) . self::LINE_ASSETS_DIR;
	}

	/**
	 * Line overlay SVGs shipped with the plugin (type_21–type_101; type_102+ when imported).
	 *
	 * @return array<string,string>
	 */
	public static function bundled_line_types() {
		$out = array();
		$dir = self::line_assets_dir();
		if ( ! is_dir( $dir ) ) {
			return $out;
		}
		for ( $i = self::BUNDLED_LINE_TYPE_MIN; $i <= self::BUNDLED_LINE_TYPE_MAX; $i++ ) {
			$key  = 'type_' . $i;
			if ( class_exists( 'PCKZ_Line_Library' ) && PCKZ_Line_Library::is_permanently_deleted_bundled( $key ) ) {
				continue;
			}
			$file = $dir . $key . '.svg';
			if ( is_readable( $file ) ) {
				$out[ $key ] = self::line_assets_url() . $key . '.svg';
			}
		}
		return $out;
	}

	/**
	 * Line overlay SVGs (Type 1–20 CDN + bundled type_21–91), without custom uploads.
	 *
	 * @return array<string,string>
	 */
	public static function base_line_types() {
		$base = 'https://cdn.shopify.com/s/files/1/0746/3672/2449/files/';
		$map  = array(
			'none'   => '',
			'type_1' => $base . 'a_ndWL_Line1.svg',
			'type_2' => $base . 'a_DdrZ_Line2.svg',
			'type_3' => $base . 'a_U57w_Line3.svg',
			'type_4' => $base . 'a_Qqgq_Type_4.svg',
			'type_5' => $base . 'a_svLa_Type_5.svg',
			'type_6' => $base . 'a_FFQ8_Type_6.svg',
			'type_7' => $base . 'a_dOm6_Type_7.svg',
			'type_8' => $base . 'a_tD3h_Type_8.svg',
			'type_9' => $base . 'a_7Idt_Type_9.svg',
			'type_10' => $base . 'a_js2U_Type_10.svg',
			'type_11' => $base . 'a_ebZG_Type_11.svg',
			'type_12' => $base . 'a_7BWS_Type_12.svg',
			'type_13' => $base . 'a_J599_Type_13.svg',
			'type_14' => $base . 'a_N54Z_Type_14.svg',
			'type_15' => $base . 'a_7sn6_Type_15.svg',
			'type_16' => $base . 'a_r6U7_Type_16.svg',
			'type_17' => $base . 'a_wkLQ_Type_17.svg',
			'type_18' => $base . 'a_1Ywc_Type_18.svg',
			'type_19' => $base . 'a_H3HV_Type_19.svg',
			'type_20' => $base . 'a_bk42_Type_20.svg',
		);
		return array_merge( $map, self::bundled_line_types() );
	}

	/**
	 * Line overlay SVGs (Type 1–20 CDN + bundled type_21–91 + custom uploads).
	 *
	 * @return array<string,string>
	 */
	public static function line_types() {
		$map = self::base_line_types();
		if ( class_exists( 'PCKZ_Line_Library' ) ) {
			foreach ( PCKZ_Line_Library::custom_manifest() as $slug => $row ) {
				unset( $row );
				$url = PCKZ_Line_Library::custom_url( $slug );
				if ( $url ) {
					$map[ $slug ] = $url;
				}
			}
		}
		return $map;
	}

	/**
	 * Default display label for a line slug.
	 *
	 * @param string $slug Line slug.
	 * @return string
	 */
	public static function default_line_label( $slug ) {
		if ( class_exists( 'PCKZ_Line_Library' ) ) {
			return PCKZ_Line_Library::default_label_for_slug( $slug );
		}
		if ( preg_match( '/^type_(\d+)$/', $slug, $m ) ) {
			return 'Typ ' . $m[1];
		}
		return $slug;
	}

	/**
	 * Line asset URLs for frontend preview only (picker endpoint; not direct disk paths).
	 *
	 * @return array<string,string>
	 */
	public static function line_types_for_preview_js() {
		$out = array();
		foreach ( self::line_types() as $slug => $url ) {
			unset( $url );
			if ( 'none' === $slug || ! class_exists( 'PCKZ_Line_Library' ) ) {
				continue;
			}
			$picker = PCKZ_Line_Library::picker_preview_url( $slug );
			if ( $picker ) {
				$out[ $slug ] = $picker;
			}
		}
		return $out;
	}

	/**
	 * Line catalog metadata for JS (no raw upload asset URLs).
	 *
	 * @return array<string,array>
	 */
	public static function line_catalog_for_js() {
		$catalog = array();
		foreach ( self::line_catalog( false, false ) as $slug => $data ) {
			if ( 'none' === $slug ) {
				continue;
			}
			$picker = class_exists( 'PCKZ_Line_Library' ) ? PCKZ_Line_Library::picker_preview_url( $slug ) : '';
			$catalog[ $slug ] = array(
				'url'             => $picker ? $picker : ( $data['preview'] ?? '' ),
				'preview'         => $picker ? $picker : ( $data['preview'] ?? '' ),
				'label'           => $data['label'] ?? $slug,
				'custom'          => ! empty( $data['custom'] ),
				'connected_right' => ! empty( $data['connected_right'] ),
				'tintable'        => ! empty( $data['tintable'] ),
				'preserve_colors' => ! empty( $data['preserve_colors'] ),
			);
		}
		return $catalog;
	}

	/**
	 * Line catalog for admin/customer UI (labels, previews, visibility).
	 *
	 * @param bool $for_customer When true, omit admin-disabled lines.
	 * @param bool $apply_order  When true, apply admin display order.
	 * @return array<string,array>
	 */
	public static function line_catalog( $for_customer = true, $apply_order = true ) {
		$none_preview = PCKZCE_PLUGIN_URL . 'public/images/icons/lines-black.svg';
		$items        = array(
			'none' => array(
				'url'     => '',
				'preview' => esc_url_raw( $none_preview ),
				'label'   => 'Keine Linien',
				'custom'  => false,
			),
		);

		foreach ( self::base_line_types() as $slug => $url ) {
			if ( 'none' === $slug || '' === $url ) {
				continue;
			}
			if ( class_exists( 'PCKZ_Line_Library' ) && PCKZ_Line_Library::is_retired_bundled_slug( $slug ) ) {
				continue;
			}
			$entry = array(
				'url'     => esc_url_raw( $url ),
				'preview' => esc_url_raw( $url ),
				'label'   => self::default_line_label( $slug ),
				'custom'  => false,
			);
			$file = self::line_assets_dir() . $slug . '.svg';
			if ( is_readable( $file ) && class_exists( 'PCKZ_Svg_Library' ) ) {
				$svg_body = (string) file_get_contents( $file );
				if ( 'preserve' === PCKZ_Svg_Library::line_color_mode_for_svg( $svg_body ) ) {
					$entry['preserve_colors'] = true;
					$entry['tintable']        = false;
				}
			}
			$items[ $slug ] = $entry;
		}

		if ( class_exists( 'PCKZ_Line_Library' ) ) {
			foreach ( PCKZ_Line_Library::custom_manifest() as $slug => $row ) {
				if ( isset( $items[ $slug ] ) ) {
					continue;
				}
				$url = PCKZ_Line_Library::custom_url( $slug );
				if ( ! $url ) {
					continue;
				}
				$preview    = PCKZ_Line_Library::preview_url( $slug );
				$color_mode = PCKZ_Line_Library::color_mode_for_slug( $slug );
				$preserve   = ( 'preserve' === $color_mode );
				$items[ $slug ] = array(
					'url'             => $url,
					'preview'         => $preview ? $preview : $url,
					'label'           => PCKZ_Line_Library::label_for_slug( $slug, self::default_line_label( $slug ) ),
					'custom'          => true,
					'connected_right' => PCKZ_Line_Library::connected_right_for_slug( $slug ),
					'tintable'        => ! $preserve,
					'preserve_colors' => $preserve,
				);
			}
			foreach ( $items as $slug => $data ) {
				if ( 'none' === $slug ) {
					continue;
				}
				$items[ $slug ]['label'] = PCKZ_Line_Library::label_for_slug( $slug, $data['label'] ?? $slug );
			}
		}

		if ( class_exists( 'PCKZ_Line_Library' ) ) {
			$items = PCKZ_Line_Library::strip_retired_from_catalog( $items );
		}

		if ( $for_customer && class_exists( 'PCKZ_Line_Library' ) ) {
			$items = PCKZ_Line_Library::filter_visible_catalog( $items );
		}

		if ( $apply_order && class_exists( 'PCKZ_Line_Library' ) ) {
			$items = PCKZ_Line_Library::sort_catalog_items( $items );
		}

		if ( class_exists( 'PCKZ_Line_Library' ) ) {
			foreach ( $items as $slug => $data ) {
				if ( 'none' === $slug ) {
					continue;
				}
				$picker = PCKZ_Line_Library::picker_preview_url( $slug );
				if ( $picker ) {
					$items[ $slug ]['preview'] = $picker;
				}
			}
		}

		return $items;
	}

	/**
	 * Social / symbol icons (subset + bundled fallbacks + premium bundled SVGs).
	 *
	 * @param bool $for_customer When true, omit admin-disabled icons.
	 * @return array<string,array>
	 */
	public static function icon_catalog( $for_customer = true ) {
		$cdn = 'https://cdn.shopify.com/s/files/1/0746/3672/2449/files/';
		$items = array(
			'none'        => array( 'url' => '', 'tintable' => false, 'label' => 'Kein Symbol' ),
			'instagram'   => array( 'url' => $cdn . 'a_KxK4_Icon_instagram.svg', 'tintable' => true ),
			'instagram_v2' => array( 'url' => $cdn . 'a_TFTB_Instagram_v2.svg', 'tintable' => true ),
			'instagram_v4' => array( 'url' => $cdn . 'a_WM81_Instagram_20v4.svg', 'tintable' => true ),
			'telegram_v1' => array( 'url' => 'https://storage.googleapis.com/cloudlift-app-cloud-prod-assets/386884-2/a_wR0e_Telegram v1.svg', 'tintable' => true ),
			'telegram_v4' => array( 'url' => 'https://cdn.shopify.com/s/files/1/0768/1048/6109/files/a_ZrX4_Telegram_20v4.svg', 'tintable' => true ),
			'facebook'    => array( 'url' => $cdn . 'a_puqt_Facebook_20v1.svg', 'tintable' => true ),
			'facebook_v2' => array( 'url' => $cdn . 'a_xkPO_Facebook_20v2.svg', 'tintable' => true ),
			'facebook_v4' => array( 'url' => $cdn . 'a_DOml_Facebook_20v4.svg', 'tintable' => true ),
			'youtube_v1'  => array( 'url' => $cdn . 'a_anAT_YouTube_20v1.svg', 'tintable' => true ),
			'youtube_v4'  => array( 'url' => $cdn . 'a_5NBS_YouTube_20v4.svg', 'tintable' => true ),
			'tiktok_v1'   => array( 'url' => $cdn . 'a_pxQh_TikTok_20v1.svg', 'tintable' => true ),
			'tiktok_v3'   => array( 'url' => $cdn . 'a_nugD_TikTok_20v3.svg', 'tintable' => true ),
			'twitter_v1'  => array( 'url' => $cdn . 'a_kmb9_Twitter_20v1.svg', 'tintable' => true ),
			'twitch_v1'   => array( 'url' => $cdn . 'a_3qNo_Twitch_20v1.svg', 'tintable' => true ),
			'verified_v1' => array( 'url' => $cdn . 'a_bx4A_Verified_20v1.svg', 'tintable' => true ),
			'football'    => array( 'url' => $cdn . 'a_madY_Icon-1.svg', 'tintable' => true ),
			'wolf'        => array( 'url' => $cdn . 'a_SNWa_Icon.svg', 'tintable' => true ),
		);

		$symbol_cdn = self::symbol_cdn_map();
		foreach ( PCKZ_Icons::symbol_choices() as $choice ) {
			$slug = $choice['value'] ?? '';
			if ( 'none' === $slug || isset( $items[ $slug ] ) ) {
				continue;
			}
			$cdn_url = $symbol_cdn[ $slug ] ?? '';
			$white   = PCKZ_Icons::icon_url( $slug, 'white' );
			$black   = PCKZ_Icons::icon_url( $slug, 'black' );
			$url = $cdn_url ?: $white ?: $black;
			if ( $url ) {
				$preview = $cdn_url ? $cdn_url : ( $black ?: $white );
				$items[ $slug ] = array(
					'url'      => esc_url_raw( $url ),
					'preview'  => esc_url_raw( $preview ),
					'tintable' => true,
					'label'    => $choice['label'] ?? $slug,
				);
			}
		}

		if ( class_exists( 'PCKZ_Icon_Library' ) ) {
			foreach ( PCKZ_Icon_Library::bundled_manifest() as $slug => $label ) {
				if ( isset( $items[ $slug ] ) ) {
					continue;
				}
				$url = PCKZ_Icon_Library::bundled_url( $slug );
				if ( ! $url ) {
					continue;
				}
				$items[ $slug ] = array(
					'url'      => $url,
					'preview'  => $url,
					'tintable' => true,
					'label'    => PCKZ_Icon_Library::label_for_slug( $slug, $label ),
					'custom'   => false,
				);
			}
			foreach ( PCKZ_Icon_Library::custom_manifest() as $slug => $row ) {
				if ( isset( $items[ $slug ] ) ) {
					continue;
				}
				$url = PCKZ_Icon_Library::custom_url( $slug );
				if ( ! $url ) {
					continue;
				}
				$color_mode = PCKZ_Icon_Library::color_mode_for_slug( $slug );
				$preserve   = ( 'preserve' === $color_mode );
				$items[ $slug ] = array(
					'url'             => $url,
					'preview'         => $url,
					'tintable'        => ! $preserve,
					'preserve_colors' => $preserve,
					'label'           => PCKZ_Icon_Library::label_for_slug( $slug, $row['label'] ?? $slug ),
					'custom'          => true,
				);
			}
			foreach ( $items as $slug => $data ) {
				if ( 'none' === $slug ) {
					continue;
				}
				$items[ $slug ]['label'] = PCKZ_Icon_Library::label_for_slug( $slug, $data['label'] ?? $slug );
			}
		}

		foreach ( $items as $slug => $data ) {
			if ( 'none' === $slug ) {
				continue;
			}
			if ( empty( $data['preview'] ) && ! empty( $data['url'] ) ) {
				$items[ $slug ]['preview'] = $data['url'];
			}
		}

		if ( $for_customer && class_exists( 'PCKZ_Icon_Library' ) ) {
			$items = PCKZ_Icon_Library::filter_visible_catalog( $items );
		}

		return $items;
	}

	/**
	 * Map simple symbol slugs to Cloudlift CDN SVG assets.
	 *
	 * @return array<string,string>
	 */
	public static function symbol_cdn_map() {
		$cdn = 'https://cdn.shopify.com/s/files/1/0746/3672/2449/files/';
		$plugin = PCKZCE_PLUGIN_URL . 'public/images/icons/';
		return array(
			'instagram' => $cdn . 'a_WM81_Instagram_20v4.svg',
			'telegram'  => 'https://cdn.shopify.com/s/files/1/0768/1048/6109/files/a_ZrX4_Telegram_20v4.svg',
			'facebook'  => $cdn . 'a_DOml_Facebook_20v4.svg',
			'tiktok'    => $cdn . 'a_nugD_TikTok_20v3.svg',
			'snapchat'  => esc_url_raw( $plugin . 'snapchat-white.svg' ),
			'whatsapp'  => esc_url_raw( $plugin . 'whatsapp-white.svg' ),
		);
	}

	/**
	 * Color swatches (text / icons / lines).
	 *
	 * @return array
	 */
	public static function color_swatches() {
		return array(
			array( 'value' => 'White', 'hex' => '#ffffff' ),
			array( 'value' => 'Red', 'hex' => '#FF0000' ),
			array( 'value' => 'Maroon', 'hex' => '#B60000' ),
			array( 'value' => 'Brown', 'hex' => '#BF733C' ),
			array( 'value' => 'Purple', 'hex' => '#CC00FF' ),
			array( 'value' => 'Magenta', 'hex' => '#FF00C7' ),
			array( 'value' => 'Yellow', 'hex' => '#FFEB34' ),
			array( 'value' => 'Orange', 'hex' => '#FFCC00' ),
			array( 'value' => 'Blue', 'hex' => '#0075FF' ),
			array( 'value' => 'Green', 'hex' => '#05DB5B' ),
			array( 'value' => 'Teal', 'hex' => '#6BFFAF' ),
			array( 'value' => 'Cyan', 'hex' => '#6BF6FF' ),
			array( 'value' => 'Violet', 'hex' => '#896BFF' ),
			array( 'value' => 'Grey', 'hex' => '#949494' ),
			array( 'value' => 'Dark Grey', 'hex' => '#424242' ),
			array( 'value' => 'Lime', 'hex' => '#bbff00' ),
		);
	}

	/**
	 * German customer options aligned with Cloudlift fields.
	 *
	 * @return array
	 */
	public static function default_cloudlift_options() {
		$colors = array();
		foreach ( self::color_swatches() as $sw ) {
			$colors[] = $sw['hex'];
		}

		$icon_choices = array();
		foreach ( self::icon_catalog() as $slug => $data ) {
			$thumb = ! empty( $data['preview'] ) ? $data['preview'] : ( $data['url'] ?? '' );
			$icon_choices[] = array(
				'value' => $slug,
				'label' => $data['label'] ?? PCKZ_Icons::label_for_slug( $slug ),
				'img'   => $thumb ? esc_url_raw( $thumb ) : '',
			);
		}

		$line_choices = array();
		foreach ( self::line_catalog( false ) as $slug => $data ) {
			if ( 'none' === $slug ) {
				$line_choices[] = array(
					'value' => 'none',
					'label' => $data['label'] ?? 'Keine Linien',
					'img'   => ! empty( $data['preview'] ) ? esc_url_raw( $data['preview'] ) : ( PCKZCE_PLUGIN_URL . 'public/images/icons/lines-black.svg' ),
				);
				continue;
			}
			$thumb = ! empty( $data['preview'] ) ? $data['preview'] : ( $data['url'] ?? '' );
			if ( ! $thumb ) {
				continue;
			}
			$line_choices[] = array(
				'value' => $slug,
				'label' => $data['label'] ?? self::default_line_label( $slug ),
				'img'   => esc_url_raw( $thumb ),
			);
		}

		$start_defaults = class_exists( 'PCKZ_Customizer_Options' )
			? PCKZ_Customizer_Options::customer_start_default_map()
			: array(
				'custom_text'   => 'Lumi-Plate',
				'symbol_links'  => 'instagram',
				'symbol_rechts' => 'tiktok',
				'font_family'   => 'Russo One',
			);

		return PCKZ_Customizer_Options::apply_customer_start_defaults(
			array(
			array(
				'id'          => 'led_enabled',
				'type'        => 'radio',
				'label'       => 'LED-Beleuchtung',
				'choices'     => array(
					array( 'value' => 'yes', 'label' => 'Ja (mit LED-Aufpreis)' ),
				),
				'default'     => 'yes',
				'locked'      => true,
			),
			array(
				'id'          => 'preview_mode',
				'type'        => 'radio',
				'label'       => 'Vorschau',
				'choices'     => array(
					array( 'value' => 'day', 'label' => 'Tag ☀️' ),
					array( 'value' => 'night', 'label' => 'Nacht 🌙' ),
				),
				'default'     => 'day',
				'preview_key' => 'background',
				'show_when'   => array( 'led_enabled' => 'no' ),
			),
			array(
				'id'          => 'preview_led',
				'type'        => 'radio',
				'label'       => 'Vorschau LED',
				'choices'     => array(
					array( 'value' => 'day', 'label' => 'Tag ☀️' ),
					array( 'value' => 'night', 'label' => 'Nacht 🌙' ),
				),
				'default'     => 'day',
				'preview_key' => 'background',
				'show_when'   => array( 'led_enabled' => 'yes' ),
			),
			array(
				'id'          => 'custom_text',
				'type'        => 'text',
				'label'       => 'Text',
				'placeholder' => 'Ihr Text',
				'default'     => $start_defaults['custom_text'] ?? 'Lumi-Plate',
				'maxlength'   => 40,
				'required'    => true,
			),
			array(
				'id'      => 'font_family',
				'type'    => 'font',
				'label'   => 'Schriftart',
				'default' => $start_defaults['font_family'] ?? 'Russo One',
			),
			array(
				'id'      => 'text_color',
				'type'    => 'swatch_color',
				'label'   => 'Textfarbe',
				'choices' => $colors,
				'default' => '#ffffff',
			),
			array(
				'id'      => 'symbol_links',
				'type'    => 'icon_select',
				'label'   => 'Symbol links',
				'choices' => $icon_choices,
				'default' => $start_defaults['symbol_links'] ?? 'instagram',
			),
			array(
				'id'      => 'icon_color_left',
				'type'    => 'swatch_color',
				'label'   => 'Symbolfarbe links',
				'choices' => $colors,
				'default' => '#ffffff',
				'show_when' => array( 'symbol_links' => '!none' ),
			),
			array(
				'id'      => 'symbol_rechts',
				'type'    => 'icon_select',
				'label'   => 'Symbol rechts',
				'choices' => $icon_choices,
				'default' => $start_defaults['symbol_rechts'] ?? 'tiktok',
			),
			array(
				'id'      => 'icon_color_right',
				'type'    => 'swatch_color',
				'label'   => 'Symbolfarbe rechts',
				'choices' => $colors,
				'default' => '#ffffff',
				'show_when' => array( 'symbol_rechts' => '!none' ),
			),
			array(
				'id'      => 'linien',
				'type'    => 'icon_select',
				'label'   => 'Linien',
				'choices' => $line_choices,
				'default' => $start_defaults['linien'] ?? ( class_exists( 'PCKZ_Line_Library' ) ? PCKZ_Line_Library::default_customer_line_slug() : 'type_1' ),
			),
			)
		);
	}

	/**
	 * Resolve hex from swatch value name.
	 *
	 * @param string $value Swatch value or hex.
	 * @return string
	 */
	/**
	 * Convert Cloudlift layer ref to mm box (bottom-left origin).
	 *
	 * @param array  $ref      Layer ref (refX, refY, refWidth, refHeight).
	 * @param float  $canvas_w Canvas width mm.
	 * @param float  $canvas_h Canvas height mm.
	 * @param string $origin   Coordinate origin.
	 * @return array
	 */
	public static function ref_to_mm_box( $ref, $canvas_w, $canvas_h, $origin = 'bottom-left' ) {
		$dw = (float) self::DESIGN_WIDTH;
		$dh = (float) self::DESIGN_HEIGHT;
		$rx = (float) ( $ref['refX'] ?? 0 );
		$ry = (float) ( $ref['refY'] ?? 0 );
		$rw = (float) ( $ref['refWidth'] ?? 0 );
		$rh = (float) ( $ref['refHeight'] ?? 0 );

		if ( class_exists( 'PCKZ_Plate_Calibration' ) ) {
			return PCKZ_Plate_Calibration::design_fraction_to_plate_mm(
				$rx / $dw,
				$ry / $dh,
				$rw / $dw,
				$rh / $dh,
				$origin,
				array(
					'canvas_width_mm'  => $canvas_w,
					'canvas_height_mm' => $canvas_h,
				)
			);
		}

		$x_mm      = ( $rx / $dw ) * $canvas_w;
		$w_mm      = ( $rw / $dw ) * $canvas_w;
		$h_mm      = ( $rh / $dh ) * $canvas_h;
		$y_top_mm  = ( $ry / $dh ) * $canvas_h;
		$y_mm      = ( 'bottom-left' === $origin ) ? ( $canvas_h - $y_top_mm - $h_mm ) : $y_top_mm;
		$center_y  = ( 'bottom-left' === $origin ) ? ( $y_mm + $h_mm / 2 ) : ( $y_top_mm + $h_mm / 2 );

		return array(
			'x_mm'        => round( $x_mm, 3 ),
			'y_mm'        => round( $y_mm, 3 ),
			'width_mm'    => round( $w_mm, 3 ),
			'height_mm'   => round( $h_mm, 3 ),
			'center_x_mm' => round( $x_mm + $w_mm / 2, 3 ),
			'center_y_mm' => round( $center_y, 3 ),
		);
	}

	/**
	 * Build guaranteed production objects from selections + layer refs (server fallback).
	 *
	 * @param array $selections Customer selections.
	 * @param float $canvas_w   Canvas W mm.
	 * @param float $canvas_h   Canvas H mm.
	 * @param string $origin    Origin.
	 * @return array
	 */
	public static function build_production_objects( $selections, $canvas_w = null, $canvas_h = null, $origin = 'bottom-left' ) {
		if ( null === $canvas_w || null === $canvas_h ) {
			$plate = class_exists( 'PCKZ_Plate_Calibration' ) ? PCKZ_Plate_Calibration::default_canvas_mm_array() : array( 'width' => 529.1, 'height' => 116 );
			$canvas_w = null === $canvas_w ? (float) $plate['width'] : (float) $canvas_w;
			$canvas_h = null === $canvas_h ? (float) $plate['height'] : (float) $canvas_h;
		}
		$refs    = self::layer_refs();
		$lines   = self::line_types();
		$icons   = self::icon_catalog();
		$objects = array();

		$text = trim( (string) ( $selections['custom_text'] ?? '' ) );
		if ( '' !== $text && ! empty( $refs['text'] ) ) {
			$text_ref = $refs['text'];
			$objects[] = array(
				'role'         => 'text',
				'text'         => $text,
				'font_family'  => $selections['font_family'] ?? 'Russo One',
				'font_size_px' => (float) ( $text_ref['fontSize'] ?? 55 ),
				'fill'         => $selections['text_color'] ?? 'White',
				'stroke'       => ( in_array( $selections['text_color'] ?? '', array( 'White', '#ffffff', '#FFFFFF' ), true ) ) ? '#000000' : '',
				'stroke_width' => (float) ( $text_ref['stroke'] ?? 0 ),
				'mm'           => self::ref_to_mm_box( $text_ref, $canvas_w, $canvas_h, $origin ),
			);
		}

		$linien = $selections['linien'] ?? 'none';
		if ( $linien && 'none' !== $linien && 'no' !== $linien && ! empty( $lines[ $linien ] ) && ! empty( $refs['lines'] ) ) {
			$objects[] = array(
				'role'      => 'lines',
				'line_type' => $linien,
				'fill'      => '',
				'svg_url'   => $lines[ $linien ],
				'mm'        => self::ref_to_mm_box( $refs['lines'], $canvas_w, $canvas_h, $origin ),
			);
		}

		$left_slug = $selections['symbol_links'] ?? 'none';
		if ( $left_slug && 'none' !== $left_slug && ! empty( $refs['iconLeft'] ) ) {
			if ( ! empty( $refs['iconBgLeft']['url'] ) ) {
				$objects[] = array(
					'role'    => 'icon-bg-left',
					'symbol'  => $left_slug,
					'fill'    => $selections['icon_color_left'] ?? 'White',
					'svg_url' => $refs['iconBgLeft']['url'],
					'mm'      => self::ref_to_mm_box( $refs['iconBgLeft'], $canvas_w, $canvas_h, $origin ),
				);
			}
			$url = $icons[ $left_slug ]['url'] ?? '';
			$objects[] = array(
				'role'    => 'icon-left',
				'symbol'  => $left_slug,
				'fill'    => $selections['icon_color_left'] ?? 'White',
				'svg_url' => $url,
				'mm'      => self::ref_to_mm_box( $refs['iconLeft'], $canvas_w, $canvas_h, $origin ),
			);
		}

		$right_slug = $selections['symbol_rechts'] ?? 'none';
		if ( $right_slug && 'none' !== $right_slug && ! empty( $refs['iconRight'] ) ) {
			if ( ! empty( $refs['iconBgRight']['url'] ) ) {
				$objects[] = array(
					'role'    => 'icon-bg-right',
					'symbol'  => $right_slug,
					'fill'    => $selections['icon_color_right'] ?? 'White',
					'svg_url' => $refs['iconBgRight']['url'],
					'mm'      => self::ref_to_mm_box( $refs['iconBgRight'], $canvas_w, $canvas_h, $origin ),
				);
			}
			$url = $icons[ $right_slug ]['url'] ?? '';
			$objects[] = array(
				'role'    => 'icon-right',
				'symbol'  => $right_slug,
				'fill'    => $selections['icon_color_right'] ?? 'White',
				'svg_url' => $url,
				'mm'      => self::ref_to_mm_box( $refs['iconRight'], $canvas_w, $canvas_h, $origin ),
			);
		}

		return $objects;
	}

	/**
	 * Merge client layout objects with synthesized fallback (fill missing roles).
	 *
	 * @param array $client     Objects from canvas.
	 * @param array $selections Selections.
	 * @param float $canvas_w   W mm.
	 * @param float $canvas_h   H mm.
	 * @param string $origin    Origin.
	 * @return array
	 */
	public static function ensure_production_objects( $client, $selections, $canvas_w, $canvas_h, $origin = 'bottom-left' ) {
		$client = is_array( $client ) ? $client : array();
		$synth  = self::build_production_objects( $selections, $canvas_w, $canvas_h, $origin );

		if ( empty( $client ) ) {
			return $synth;
		}

		$roles_present = array();
		foreach ( $client as $obj ) {
			$roles_present[ $obj['role'] ?? '' ] = true;
		}

		$merged = $client;
		foreach ( $synth as $obj ) {
			$role = $obj['role'] ?? '';
			if ( empty( $roles_present[ $role ] ) ) {
				$merged[] = $obj;
			}
		}

		return $merged;
	}

	public static function hex_for_color_value( $value ) {
		if ( preg_match( '/^#([A-Fa-f0-9]{3}|[A-Fa-f0-9]{6})$/', (string) $value ) ) {
			return sanitize_hex_color( $value );
		}
		foreach ( self::color_swatches() as $sw ) {
			if ( ( $sw['value'] ?? '' ) === $value ) {
				return $sw['hex'];
			}
		}
		return '#ffffff';
	}
}
