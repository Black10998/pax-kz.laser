<?php
/**
 * Custom line uploads and admin visibility controls for Linien picker.
 *
 * @package PCKZCanonicalEngine
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class PCKZ_Line_Library
 */
class PCKZ_Line_Library {

	const OPTION_DISABLED = 'pckz_line_disabled_slugs';
	const OPTION_CUSTOM   = 'pckz_line_custom';
	const OPTION_LABELS   = 'pckz_line_labels';
	const UPLOAD_SUBDIR   = 'pckz-canonical-engine/lines';

	/**
	 * Safe option getter for CLI smoke environments.
	 *
	 * @param string $key Option key.
	 * @param mixed  $default Default value.
	 * @return mixed
	 */
	private static function option_get( $key, $default = null ) {
		if ( function_exists( 'get_option' ) ) {
			return get_option( $key, $default );
		}
		return $default;
	}

	/**
	 * Safe option setter for CLI smoke environments.
	 *
	 * @param string $key   Option key.
	 * @param mixed  $value Option value.
	 */
	private static function option_update( $key, $value ) {
		if ( function_exists( 'update_option' ) ) {
			update_option( $key, $value );
		}
	}

	/**
	 * Custom uploaded lines.
	 *
	 * @return array<string,array{label:string,file:string,customer_visible:bool}>
	 */
	public static function custom_manifest() {
		$raw = self::option_get( self::OPTION_CUSTOM, array() );
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$disabled = self::disabled_slugs();
		$out      = array();
		foreach ( $raw as $slug => $row ) {
			$slug = sanitize_key( $slug );
			if ( ! $slug || ! is_array( $row ) || empty( $row['file'] ) ) {
				continue;
			}
			if ( ! is_readable( self::upload_dir() . '/' . sanitize_file_name( $row['file'] ) ) ) {
				continue;
			}
			if ( array_key_exists( 'customer_visible', $row ) ) {
				$visible = (bool) $row['customer_visible'];
			} else {
				$visible = ! in_array( $slug, $disabled, true );
			}
			$out[ $slug ] = array(
				'label'            => sanitize_text_field( $row['label'] ?? $slug ),
				'file'             => sanitize_file_name( $row['file'] ),
				'customer_visible' => $visible,
			);
		}
		return $out;
	}

	/**
	 * Label overrides for any slug.
	 *
	 * @return array<string,string>
	 */
	public static function label_overrides() {
		$raw = self::option_get( self::OPTION_LABELS, array() );
		return is_array( $raw ) ? $raw : array();
	}

	/**
	 * Default label for a line slug (Typ N for type_N).
	 *
	 * @param string $slug Line slug.
	 * @return string
	 */
	public static function default_label_for_slug( $slug ) {
		if ( preg_match( '/^type_(\d+)$/', $slug, $m ) ) {
			return 'Typ ' . $m[1];
		}
		return $slug;
	}

	/**
	 * Display label for slug.
	 *
	 * @param string $slug Icon slug.
	 * @param string $fallback Fallback.
	 * @return string
	 */
	public static function label_for_slug( $slug, $fallback = '' ) {
		$overrides = self::label_overrides();
		if ( ! empty( $overrides[ $slug ] ) ) {
			return $overrides[ $slug ];
		}
		$custom = self::custom_manifest();
		if ( isset( $custom[ $slug ]['label'] ) ) {
			return $custom[ $slug ]['label'];
		}
		return $fallback ?: self::default_label_for_slug( $slug );
	}

	/**
	 * Whether slug is custom upload.
	 *
	 * @param string $slug Line slug.
	 * @return bool
	 */
	public static function is_custom( $slug ) {
		return isset( self::custom_manifest()[ $slug ] );
	}

	/**
	 * Upload directory.
	 *
	 * @return string
	 */
	public static function upload_dir() {
		$upload = wp_upload_dir();
		$dir    = trailingslashit( $upload['basedir'] ) . self::UPLOAD_SUBDIR;
		if ( ! file_exists( $dir ) ) {
			wp_mkdir_p( $dir );
		}
		return $dir;
	}

	/**
	 * Upload base URL.
	 *
	 * @return string
	 */
	public static function upload_url_base() {
		$upload = wp_upload_dir();
		return trailingslashit( $upload['baseurl'] ) . self::UPLOAD_SUBDIR;
	}

	/**
	 * Public URL for custom line SVG.
	 *
	 * @param string $slug Line slug.
	 * @return string
	 */
	public static function custom_url( $slug ) {
		$slug   = sanitize_key( $slug );
		$custom = self::custom_manifest();
		if ( empty( $custom[ $slug ]['file'] ) ) {
			return '';
		}
		return esc_url_raw( self::upload_url_base() . '/' . $custom[ $slug ]['file'] );
	}

	/**
	 * Slugs disabled in admin (hidden from customer selector).
	 *
	 * @return string[]
	 */
	public static function disabled_slugs() {
		$raw = self::option_get( self::OPTION_DISABLED, array() );
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$out = array();
		foreach ( $raw as $slug ) {
			$s = sanitize_key( $slug );
			if ( $s && 'none' !== $s ) {
				$out[] = $s;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Whether line appears in customer-facing catalog/selector.
	 *
	 * @param string $slug Line slug.
	 * @return bool
	 */
	public static function is_visible( $slug ) {
		if ( 'none' === $slug || '' === $slug ) {
			return true;
		}
		$slug = sanitize_key( $slug );
		if ( self::is_custom( $slug ) ) {
			$custom = self::custom_manifest();
			if ( isset( $custom[ $slug ] ) ) {
				return ! empty( $custom[ $slug ]['customer_visible'] );
			}
			return true;
		}
		return ! in_array( $slug, self::disabled_slugs(), true );
	}

	/**
	 * Build compact admin save payload from the current catalog state.
	 *
	 * @return array{lines:array<string,array{enabled:bool,label:string}>}
	 */
	public static function build_admin_save_payload() {
		$lines = array();
		foreach ( self::admin_catalog_entries() as $slug => $data ) {
			if ( 'none' === $slug ) {
				continue;
			}
			$lines[ $slug ] = array(
				'enabled' => self::is_visible( $slug ),
				'label'   => (string) ( $data['label'] ?? self::label_for_slug( $slug, $slug ) ),
			);
		}
		return array( 'lines' => $lines );
	}

	/**
	 * Customer-facing Linien picker choices (live catalog, not stored product snapshot).
	 *
	 * @return array<int,array{value:string,label:string,img:string}>
	 */
	public static function get_customer_line_choices() {
		if ( ! class_exists( 'PCKZ_Ledos_Preview' ) ) {
			return array();
		}
		$choices = array();
		foreach ( PCKZ_Ledos_Preview::line_catalog( true ) as $slug => $data ) {
			$thumb = ! empty( $data['preview'] ) ? $data['preview'] : ( $data['url'] ?? '' );
			$choices[] = array(
				'value' => $slug,
				'label' => $data['label'] ?? self::label_for_slug( $slug, $slug ),
				'img'   => $thumb ? esc_url_raw( $thumb ) : '',
			);
		}
		return $choices;
	}

	/**
	 * Filter catalog entries for customer UI.
	 *
	 * @param array<string,array> $items Line catalog.
	 * @return array<string,array>
	 */
	public static function filter_visible_catalog( $items ) {
		foreach ( $items as $slug => $data ) {
			if ( ! self::is_visible( $slug ) ) {
				unset( $items[ $slug ] );
			}
		}
		return $items;
	}

	/**
	 * All catalog slugs for admin (unfiltered).
	 *
	 * @return array<string,array>
	 */
	public static function admin_catalog_entries() {
		if ( ! class_exists( 'PCKZ_Ledos_Preview' ) ) {
			return array();
		}
		return PCKZ_Ledos_Preview::line_catalog( false );
	}

	/**
	 * Next available type_N slug for a new upload.
	 *
	 * @return string
	 */
	public static function next_upload_slug() {
		$max = class_exists( 'PCKZ_Ledos_Preview' ) ? PCKZ_Ledos_Preview::BUNDLED_LINE_TYPE_MAX : 71;
		if ( class_exists( 'PCKZ_Ledos_Preview' ) ) {
			foreach ( PCKZ_Ledos_Preview::base_line_types() as $slug => $url ) {
				unset( $url );
				if ( preg_match( '/^type_(\d+)$/', $slug, $m ) ) {
					$max = max( $max, (int) $m[1] );
				}
			}
		}
		foreach ( array_keys( self::custom_manifest() ) as $slug ) {
			if ( preg_match( '/^type_(\d+)$/', $slug, $m ) ) {
				$max = max( $max, (int) $m[1] );
			}
		}
		return 'type_' . ( $max + 1 );
	}

	/**
	 * Handle SVG upload.
	 *
	 * @param array $file $_FILES row.
	 * @return array|WP_Error
	 */
	public static function handle_upload( $file ) {
		if ( empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
			return new WP_Error( 'no_file', __( 'Keine SVG-Datei empfangen.', 'pckz-canonical-engine' ) );
		}
		$check = wp_check_filetype( $file['name'], array( 'svg' => 'image/svg+xml' ) );
		if ( empty( $check['ext'] ) || 'svg' !== $check['ext'] ) {
			return new WP_Error( 'bad_type', __( 'Nur SVG-Dateien sind erlaubt.', 'pckz-canonical-engine' ) );
		}
		$contents = file_get_contents( $file['tmp_name'] );
		if ( false === $contents || ! self::is_safe_svg( $contents ) ) {
			return new WP_Error( 'unsafe_svg', __( 'SVG enthält nicht erlaubte Inhalte.', 'pckz-canonical-engine' ) );
		}
		$slug     = self::next_upload_slug();
		$filename = $slug . '.svg';
		$dest     = self::upload_dir() . '/' . $filename;
		if ( ! file_put_contents( $dest, $contents ) ) {
			return new WP_Error( 'write_fail', __( 'SVG konnte nicht gespeichert werden.', 'pckz-canonical-engine' ) );
		}
		$base  = sanitize_title( pathinfo( $file['name'], PATHINFO_FILENAME ) );
		$label = isset( $_POST['line_upload_label'] ) ? sanitize_text_field( wp_unslash( $_POST['line_upload_label'] ) ) : self::default_label_for_slug( $slug );
		if ( '' === $label ) {
			$label = self::default_label_for_slug( $slug );
		}
		$custom = self::option_get( self::OPTION_CUSTOM, array() );
		if ( ! is_array( $custom ) ) {
			$custom = array();
		}
		$custom[ $slug ] = array(
			'label'            => $label,
			'file'             => $filename,
			'customer_visible' => true,
		);
		self::option_update( self::OPTION_CUSTOM, $custom );

		$disabled = array_values(
			array_diff( self::disabled_slugs(), array( $slug ) )
		);
		self::option_update( self::OPTION_DISABLED, $disabled );

		return array( 'slug' => $slug );
	}

	/**
	 * Basic SVG safety check.
	 *
	 * @param string $svg SVG source.
	 * @return bool
	 */
	public static function is_safe_svg( $svg ) {
		if ( stripos( $svg, '<script' ) !== false || stripos( $svg, '<?php' ) !== false ) {
			return false;
		}
		return (bool) preg_match( '/<svg[\s>]/i', $svg );
	}

	/**
	 * Delete custom line.
	 *
	 * @param string $slug Slug.
	 * @return bool|WP_Error
	 */
	public static function delete_custom( $slug ) {
		$slug   = sanitize_key( $slug );
		$custom = self::option_get( self::OPTION_CUSTOM, array() );
		if ( ! is_array( $custom ) || empty( $custom[ $slug ] ) ) {
			return new WP_Error( 'not_custom', __( 'Nur hochgeladene Linien können gelöscht werden.', 'pckz-canonical-engine' ) );
		}
		$file = $custom[ $slug ]['file'] ?? '';
		unset( $custom[ $slug ] );
		self::option_update( self::OPTION_CUSTOM, $custom );
		if ( $file ) {
			$path = self::upload_dir() . '/' . sanitize_file_name( $file );
			if ( is_readable( $path ) ) {
				if ( function_exists( 'wp_delete_file' ) ) {
					wp_delete_file( $path );
				} else {
					unlink( $path );
				}
			}
		}
		$labels = self::label_overrides();
		if ( isset( $labels[ $slug ] ) ) {
			unset( $labels[ $slug ] );
			self::option_update( self::OPTION_LABELS, $labels );
		}
		return true;
	}

	/**
	 * Parse compact JSON payload from line library save form.
	 *
	 * @param mixed $payload Decoded or raw payload.
	 * @return array{enabled:string[],labels:array<string,string>}|null
	 */
	public static function parse_admin_save_payload( $payload ) {
		if ( is_string( $payload ) ) {
			$payload = trim( $payload );
			if ( '' === $payload ) {
				return null;
			}
			$payload = json_decode( wp_unslash( $payload ), true );
			if ( JSON_ERROR_NONE !== json_last_error() ) {
				return null;
			}
		}
		if ( ! is_array( $payload ) || empty( $payload['lines'] ) || ! is_array( $payload['lines'] ) ) {
			return null;
		}

		$known   = self::admin_catalog_entries();
		$custom  = array_keys( self::custom_manifest() );
		$enabled = array();
		$labels  = array();

		foreach ( $payload['lines'] as $slug => $row ) {
			$slug = sanitize_key( (string) $slug );
			if ( ! $slug || 'none' === $slug ) {
				continue;
			}
			if ( ! isset( $known[ $slug ] ) && ! in_array( $slug, $custom, true ) ) {
				continue;
			}
			if ( ! empty( $row['enabled'] ) ) {
				$enabled[] = $slug;
			}
			if ( isset( $row['label'] ) ) {
				$label = sanitize_text_field( (string) $row['label'] );
				if ( '' !== $label ) {
					$labels[ $slug ] = $label;
				}
			}
		}

		return array(
			'enabled' => array_values( array_unique( $enabled ) ),
			'labels'  => $labels,
		);
	}

	/**
	 * Save line library admin form submission.
	 *
	 * @param array $post Raw $_POST.
	 * @return true|WP_Error
	 */
	public static function save_admin_state_from_post( $post ) {
		$parsed = null;
		if ( ! empty( $post['pckz_line_library_payload'] ) ) {
			$parsed = self::parse_admin_save_payload( $post['pckz_line_library_payload'] );
		}

		if ( ! is_array( $parsed ) ) {
			return new WP_Error(
				'line_library_empty_payload',
				__( 'Line library save failed: no line state was received. Reload the page and try again.', 'pckz-canonical-engine' )
			);
		}

		self::save_admin_state( $parsed['enabled'], $parsed['labels'] );
		return true;
	}

	/**
	 * Save visibility + labels from admin.
	 *
	 * @param array $enabled_slugs Enabled slugs.
	 * @param array $labels        Slug => label.
	 */
	public static function save_admin_state( $enabled_slugs, $labels ) {
		$all      = array_keys( self::admin_catalog_entries() );
		$enabled  = array();
		foreach ( (array) $enabled_slugs as $slug ) {
			$slug = sanitize_key( (string) $slug );
			if ( $slug && 'none' !== $slug ) {
				$enabled[] = $slug;
			}
		}
		$enabled  = array_values( array_unique( $enabled ) );
		$disabled = array();
		foreach ( $all as $slug ) {
			if ( 'none' === $slug ) {
				continue;
			}
			if ( ! in_array( $slug, $enabled, true ) ) {
				$disabled[] = $slug;
			}
		}
		self::option_update( self::OPTION_DISABLED, $disabled );
		$clean = array();
		if ( is_array( $labels ) ) {
			foreach ( $labels as $slug => $label ) {
				$slug  = sanitize_key( (string) $slug );
				$label = sanitize_text_field( (string) $label );
				if ( $slug && 'none' !== $slug && '' !== $label ) {
					$clean[ $slug ] = $label;
				}
			}
		}
		self::option_update( self::OPTION_LABELS, $clean );

		$custom_raw = self::option_get( self::OPTION_CUSTOM, array() );
		if ( is_array( $custom_raw ) ) {
			foreach ( $custom_raw as $slug => $row ) {
				$slug = sanitize_key( (string) $slug );
				if ( ! $slug || ! is_array( $row ) || empty( $row['file'] ) ) {
					continue;
				}
				$custom_raw[ $slug ]['customer_visible'] = in_array( $slug, $enabled, true );
				if ( isset( $clean[ $slug ] ) ) {
					$custom_raw[ $slug ]['label'] = $clean[ $slug ];
				}
			}
			self::option_update( self::OPTION_CUSTOM, $custom_raw );
		}
	}
}
